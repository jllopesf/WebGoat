package org.owasp.webgoat.plugin;

/**
 * Interface with constants so we can easily change the flags
 *
 * @author nbaars
 * @since 3/23/17.
 */
public interface SolutionConstants {

    //TODO should be random generated when starting the server
    String PASSWORD = "!!webgoat_admin_1234!!";
    String SUPER_COUPON_CODE = "get_it_for_free";
    String PASSWORD_TOM = "thisisasecretfortomonly";
    String PASSWORD_LARRY = "larryknows";
    String JWT_PASSWORD = "victory";

}
